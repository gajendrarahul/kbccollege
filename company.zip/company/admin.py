from django.contrib import admin
from  .models import Comapany, Job
# Register your models here.
admin.site.register(Comapany)
admin.site.register(Job)
